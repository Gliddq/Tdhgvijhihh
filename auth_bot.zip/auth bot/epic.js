const { ActivityType, PresenceUpdateStatus } = require("discord.js");
module.exports = {
  client_id: "1139171369687453756", // client id ",
  client_secret: "78JhyaI-ErzOnwjopJ3TpxdzfFrG-3mI", // bot secret
  redirect_uri: "http://node1.adky.net:2213/", //redirect url
  mainserver: "https://discord.gg/",
  footer: "Malik Cord", //you can change it 
  support: "Made By Malik Dev", //not required
  backupchannelid: "1174785241093775381", // channel for auth to backup to 
  statuschannel: {
    userhookurl: "https://discord.com/api/webhooks/1174744954321506434/5xmMGaxMMfrcpHBQpKbR0yg3du6snn6DipiwzNwE43-5G89op0KL4C_NFbGOsLI9UklO", // new auth log
    serverhookurl: "https://discord.com/api/webhooks/1174744876139683931/BjHvnafCwhyMmnqSpY1rvctlj2QTOLmwpP2DJmj5qLJDlSY3l1WP0_242t9NDnwNqQ6C", //new server log
    enabled: false, //dum thing that spams ur webhook 
    interval: 6000 // intravel to spam thte user and server stats
  },
  emojis: {
    already: "`❌`",
    deleted: "`❌`",
    dot: "",
    error: "`☢`",
    limitusers: "`🚫v",
    msg: "`⏰`",
    onlineusers: "`✅`",
    progress: "",
    succes: "`✅`",
    unsucces: "`❌`",
    hehe: "`🤼‍♂️`",
    users: "`🤼‍♂️`",
  },
  owners: ["1174716980914298964" , "1166784750233604196"], //example for multiple ids ["owner_1_id", "owner_2_id"])
  token: "MTEzOTE3MTM2OTY4NzQ1Mzc1Ng.Gph8w0.7qiFbyya2e6kzSiLsOmowx4RaBoTjFYtszQ7v8",
  webhooks: {
    general: "https://discord.com/api/webhooks/1174744876139683931/BjHvnafCwhyMmnqSpY1rvctlj2QTOLmwpP2DJmj5qLJDlSY3l1WP0_242t9NDnwNqQ6C",
    join: "https://discord.com/api/webhooks/1174744954321506434/5xmMGaxMMfrcpHBQpKbR0yg3du6snn6DipiwzNwE43-5G89op0KL4C_NFbGOsLI9UklO",
    //debug:""
  },
  durum: "Made By LawiDev",
  type: ActivityType.Playing,
  status: PresenceUpdateStatus.Idle,
}
//nigga epic fr